import SwiftUI
struct TripListView: View { var body: some View { Text("trips") } }
